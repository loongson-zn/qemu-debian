/* distro specific configuration injected by the distro build.  */

#ifndef ACCEL_COMPILER
#endif
